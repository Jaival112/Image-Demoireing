import os

import gradio as gr

from infer import demoire_image, load_model

WEIGHTS = os.environ.get("DEMOIRE_WEIGHTS", "checkpoints/best.pth")
net, device = load_model(WEIGHTS if os.path.exists(WEIGHTS) else None)
if not os.path.exists(WEIGHTS):
    print(f"WARNING: {WEIGHTS} not found, running with untrained weights.")


def run(img, tile):
    if img is None:
        return None
    return demoire_image(img, net, device, tile=int(tile))


demo = gr.Interface(
    fn=run,
    inputs=[
        gr.Image(type="pil", label="Photo with moiré"),
        gr.Slider(256, 1024, value=512, step=128, label="Tile size (lower = less memory)"),
    ],
    outputs=gr.Image(type="pil", label="Demoiréd result"),
    title="Image Demoiréing",
    description="Upload a photo of a screen and get the moiré patterns removed.",
)

if __name__ == "__main__":
    demo.launch()
