# Image Demoiréing

## Setup
    pip install torch torchvision pillow numpy gradio

## 1. Train
Put paired images (same filenames) in:

    data/train/moire/   data/train/clean/
    data/val/moire/     data/val/clean/

Datasets: UHDM, FHDMi, TIP2018, LCDMoiré. Then:

    python train.py --data data --epochs 100 --bs 8 --crop 256

Best weights are saved to `checkpoints/best.pth`.

## 2. Run the app (user uploads an image)
    python app.py

Use a different weights file with `DEMOIRE_WEIGHTS=path/to/file.pth python app.py`.

## 3. Command line
    python infer.py input.jpg output.png --weights checkpoints/best.pth

## Notes
- Without trained weights the app runs but output is essentially the input.
- Large photos are processed in overlapping tiles; lower the tile size if you run out of memory.
- Never resize training images, crop instead.
- For higher quality, swap `DemoireNet` for ESDNet (github.com/CVMI-Lab/UHDM) and load its
  pretrained weights in `load_model`.
