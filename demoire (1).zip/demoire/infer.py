import numpy as np
import torch
from PIL import Image

from model import DemoireNet


def load_model(weights=None, device=None):
    device = device or ("cuda" if torch.cuda.is_available() else "cpu")
    net = DemoireNet().to(device).eval()
    if weights:
        state = torch.load(weights, map_location=device)
        net.load_state_dict(state.get("model", state))
    return net, device


@torch.no_grad()
def demoire_image(img: Image.Image, net, device, tile=512, overlap=64):
    """Tiled inference with smooth blending so large photos fit in memory."""
    x = torch.from_numpy(np.asarray(img.convert("RGB"), dtype=np.float32) / 255.0)
    x = x.permute(2, 0, 1).unsqueeze(0).to(device)
    _, _, H, W = x.shape

    if H <= tile and W <= tile:
        y = net(x).clamp(0, 1)
    else:
        stride = tile - overlap
        out = torch.zeros_like(x)
        weight = torch.zeros(1, 1, H, W, device=device)
        win1d = torch.hann_window(tile, periodic=False, device=device).clamp_min(1e-3)
        win = (win1d[:, None] * win1d[None, :])[None, None]
        ys = list(range(0, max(H - tile, 0) + 1, stride))
        xs = list(range(0, max(W - tile, 0) + 1, stride))
        if ys[-1] + tile < H:
            ys.append(H - tile)
        if xs[-1] + tile < W:
            xs.append(W - tile)
        for top in ys:
            for left in xs:
                t = min(tile, H - top)
                l = min(tile, W - left)
                patch = x[..., top:top + t, left:left + l]
                pred = net(patch)
                wpatch = win[..., :t, :l]
                out[..., top:top + t, left:left + l] += pred * wpatch
                weight[..., top:top + t, left:left + l] += wpatch
        y = (out / weight).clamp(0, 1)

    arr = (y[0].permute(1, 2, 0).cpu().numpy() * 255).round().astype(np.uint8)
    return Image.fromarray(arr)


if __name__ == "__main__":
    import argparse

    p = argparse.ArgumentParser()
    p.add_argument("input")
    p.add_argument("output")
    p.add_argument("--weights", default=None)
    a = p.parse_args()
    net, dev = load_model(a.weights)
    demoire_image(Image.open(a.input), net, dev).save(a.output)
