import torch
import torch.nn as nn
import torch.nn.functional as F


class ResBlock(nn.Module):
    def __init__(self, c):
        super().__init__()
        self.body = nn.Sequential(
            nn.Conv2d(c, c, 3, 1, 1), nn.GELU(), nn.Conv2d(c, c, 3, 1, 1)
        )

    def forward(self, x):
        return x + self.body(x)


def stage(c, n):
    return nn.Sequential(*[ResBlock(c) for _ in range(n)])


class DemoireNet(nn.Module):
    """3-level residual U-Net. Predicts a correction added to the input."""

    def __init__(self, c=48, blocks=(2, 2, 4)):
        super().__init__()
        self.inp = nn.Conv2d(3, c, 3, 1, 1)
        self.enc1 = stage(c, blocks[0])
        self.down1 = nn.Conv2d(c, c * 2, 2, 2)
        self.enc2 = stage(c * 2, blocks[1])
        self.down2 = nn.Conv2d(c * 2, c * 4, 2, 2)
        self.mid = stage(c * 4, blocks[2])
        self.up2 = nn.ConvTranspose2d(c * 4, c * 2, 2, 2)
        self.dec2 = stage(c * 2, blocks[1])
        self.up1 = nn.ConvTranspose2d(c * 2, c, 2, 2)
        self.dec1 = stage(c, blocks[0])
        self.out = nn.Conv2d(c, 3, 3, 1, 1)

    def forward(self, x):
        h, w = x.shape[-2:]
        ph, pw = (-h) % 4, (-w) % 4
        xp = F.pad(x, (0, pw, 0, ph), mode="reflect") if (ph or pw) else x
        e1 = self.enc1(self.inp(xp))
        e2 = self.enc2(self.down1(e1))
        m = self.mid(self.down2(e2))
        d2 = self.dec2(self.up2(m) + e2)
        d1 = self.dec1(self.up1(d2) + e1)
        y = xp + self.out(d1)
        return y[..., :h, :w]
