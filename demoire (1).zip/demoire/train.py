"""Train on paired data laid out as:
    data/train/moire/xxx.png   data/train/clean/xxx.png
    data/val/moire/xxx.png     data/val/clean/xxx.png
(matching filenames in both folders)
"""
import argparse
import math
import os
import random

import numpy as np
import torch
import torch.nn as nn
from PIL import Image
from torch.utils.data import DataLoader, Dataset

from model import DemoireNet


class PairDataset(Dataset):
    def __init__(self, root, crop=256, train=True):
        self.m = os.path.join(root, "moire")
        self.c = os.path.join(root, "clean")
        self.files = sorted(os.listdir(self.m))
        self.crop, self.train = crop, train

    def __len__(self):
        return len(self.files)

    def __getitem__(self, i):
        f = self.files[i]
        a = Image.open(os.path.join(self.m, f)).convert("RGB")
        b = Image.open(os.path.join(self.c, f)).convert("RGB")
        a = np.asarray(a, dtype=np.float32) / 255
        b = np.asarray(b, dtype=np.float32) / 255
        H, W = a.shape[:2]
        cs = self.crop
        # crop only (never resize: resizing destroys the moiré structure)
        t = random.randint(0, H - cs) if self.train else (H - cs) // 2
        l = random.randint(0, W - cs) if self.train else (W - cs) // 2
        a, b = a[t:t + cs, l:l + cs], b[t:t + cs, l:l + cs]
        if self.train:
            if random.random() < 0.5:
                a, b = a[:, ::-1], b[:, ::-1]
            if random.random() < 0.5:
                a, b = a[::-1], b[::-1]
        to_t = lambda z: torch.from_numpy(np.ascontiguousarray(z)).permute(2, 0, 1)
        return to_t(a), to_t(b)


def charbonnier(p, t, eps=1e-3):
    return torch.sqrt((p - t) ** 2 + eps ** 2).mean()


def freq_loss(p, t):
    return (torch.fft.rfft2(p) - torch.fft.rfft2(t)).abs().mean()


def psnr(p, t):
    mse = ((p.clamp(0, 1) - t) ** 2).mean().item()
    return 10 * math.log10(1 / max(mse, 1e-10))


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--data", default="data")
    ap.add_argument("--epochs", type=int, default=100)
    ap.add_argument("--bs", type=int, default=8)
    ap.add_argument("--crop", type=int, default=256)
    ap.add_argument("--lr", type=float, default=2e-4)
    a = ap.parse_args()

    dev = "cuda" if torch.cuda.is_available() else "cpu"
    tr = DataLoader(PairDataset(f"{a.data}/train", a.crop), a.bs, shuffle=True,
                    num_workers=4, drop_last=True)
    va = DataLoader(PairDataset(f"{a.data}/val", a.crop, train=False), 1)

    net = DemoireNet().to(dev)
    opt = torch.optim.AdamW(net.parameters(), lr=a.lr, weight_decay=1e-4)
    sched = torch.optim.lr_scheduler.CosineAnnealingLR(opt, a.epochs)
    scaler = torch.cuda.amp.GradScaler(enabled=dev == "cuda")
    os.makedirs("checkpoints", exist_ok=True)
    best = 0

    for ep in range(a.epochs):
        net.train()
        for x, y in tr:
            x, y = x.to(dev), y.to(dev)
            with torch.autocast(dev, enabled=dev == "cuda"):
                p = net(x)
            p = p.float()
            loss = charbonnier(p, y) + 0.1 * freq_loss(p, y)
            opt.zero_grad(set_to_none=True)
            scaler.scale(loss).backward()
            scaler.step(opt)
            scaler.update()
        sched.step()

        net.eval()
        with torch.no_grad():
            score = np.mean([psnr(net(x.to(dev)), y.to(dev)) for x, y in va])
        print(f"epoch {ep + 1}/{a.epochs}  loss {loss.item():.4f}  val PSNR {score:.2f}")
        torch.save({"model": net.state_dict()}, "checkpoints/last.pth")
        if score > best:
            best = score
            torch.save({"model": net.state_dict()}, "checkpoints/best.pth")


if __name__ == "__main__":
    main()
